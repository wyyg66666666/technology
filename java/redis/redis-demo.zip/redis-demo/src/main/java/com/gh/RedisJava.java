package com.gh;
public class RedisJava {

	public static void main(String[] args) {
		RedisPool.getJedis().set("name","郭红");
		System.out.println(RedisPool.getJedis().get("name"));
	}
}