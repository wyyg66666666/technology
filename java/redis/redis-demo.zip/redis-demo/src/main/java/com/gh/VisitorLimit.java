package com.gh;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.Transaction;

public class VisitorLimit {

	private Jedis jedis;

	@Before
	public void setJedis() {
		//连接redis服务器(在这里是连接本地的)
		jedis = new Jedis("127.0.0.1", 6379);
		//权限认证
		jedis.auth("guohong");
		System.out.println("连接服务成功");
	}

	/**
	 * 限制网站访客访问频率 一分钟之内最多访问10次
	 * 
	 * @throws Exception
	 */
	@Test
	public void test3() throws Exception {
		// 模拟用户的频繁请求
		for (int i = 0; i < 20; i++) {
			boolean result = testLogin("192.168.1.101");
			if (result) {
				System.out.println("正常访问");
			} else {
				System.err.println("访问受限");
			}
		}

	}

	/**
	 * 判断用户是否可以访问网站
	 * 
	 * @param ip
	 * @return
	 */
	public boolean testLogin(String ip) {
		String value = jedis.get(ip);
		if (value == null) {
			// 初始化时设置IP访问次数为1
			jedis.set(ip, "1");
			// 设置IP的生存时间为60秒，60秒内IP的访问次数由程序控制
			jedis.expire(ip, 60);
		} else {
			int parseInt = Integer.parseInt(value);
			// 如果60秒内IP的访问次数超过10，返回false,实现了超过10次禁止分的功能
			if (parseInt > 10) {
				return false;
			} else {
				// 如果没有10次，可以自增
				jedis.incr(ip);
			}
		}
		return true;
	}

	/**
	 * 监控变量a在一段时间内是否被修改，若没有，则执行事务，若被修改，则事务不执行
	 * 
	 * @throws Exception
	 */
	@Test
	public void test4() throws Exception {
		// 监控变量a，在事务执行后watch功能也结束
		jedis.watch("a");
		// 需要数据库中先有a，并且a的值为字符串数字
		String value = jedis.get("a");
		int parseInt = Integer.parseInt(value);
		parseInt++;
		System.out.println("线程开始休息。。。"+value);
		Thread.sleep(10000);

		// 开启事务
		Transaction transaction = jedis.multi();
		transaction.set("a", parseInt + "");
		// 执行事务
		List<Object> exec = transaction.exec();
		if (exec == null) {
			System.out.println("事务没有执行.....");
		} else {
			System.out.println("正常执行......");
		}
	}
	
}
