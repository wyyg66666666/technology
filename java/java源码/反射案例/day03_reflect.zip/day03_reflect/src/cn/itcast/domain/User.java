package cn.itcast.domain;

public class User {

	private String name;
	private String age;
	private String tel;
	private String address;
	private String qq;
	@Override
	public String toString() {
		return "User [address=" + address + ", age=" + age + ", name=" + name
				+ ", qq=" + qq + ", tel=" + tel + "]";
	}

	
	
	
	
}
