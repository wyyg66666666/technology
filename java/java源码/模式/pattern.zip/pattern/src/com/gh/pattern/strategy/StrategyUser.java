package com.gh.pattern.strategy;

/**
 * 客户端，此类是策略的执行者
 * @author Administrator
 *
 */
public class StrategyUser {

	public static void main(String[] args) {
		
		StoregeStrategy storegeStrategy = new StoregeStrategy(new RunStrategy());
		//执行策略
		storegeStrategy.operate();

	}

}
