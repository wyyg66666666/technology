package com.gh.pattern.builder;

public class OperateString {
	
	public final static String ENGINE = "engine boom";
	public final static String START = "start";
	public final static String STOP = "stop";
	public final static String ALARM = "alarm";

}
