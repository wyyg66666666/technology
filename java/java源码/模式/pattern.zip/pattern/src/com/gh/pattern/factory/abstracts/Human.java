package com.gh.pattern.factory.abstracts;
/**
* @author cbf4Life cbf4life@126.com
* I'm glad to share my knowledge with you all.
* 定义一个人类的统称，问题出来了，刚刚定义的时候忘记定义性别了
* 这个重要的问题非修改不可，否则这个世界上太多太多的东西不存在了
*/
public interface Human {
	/**
	 * 人会笑
	 */
	public void laugh();
	/**
	 * 人会 哭
	 */
	public void cry();
	/**
	 * 定义性别
	 */
	public void setSex();

}
