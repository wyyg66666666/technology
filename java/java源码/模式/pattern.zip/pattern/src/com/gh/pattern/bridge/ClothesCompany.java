package com.gh.pattern.bridge;
/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * 服装公司，这个行当现在不怎么样
 */
public class ClothesCompany extends Company{

	public ClothesCompany(House house) {
		//定义传递一个House产品进来
		super(house);
	}

	//服装公司不景气，但怎么说也是赚钱行业也
	public void makeMoney(){
		super.makeMoney();
		System.out.println("服装公司赚小钱...");
	}

}
