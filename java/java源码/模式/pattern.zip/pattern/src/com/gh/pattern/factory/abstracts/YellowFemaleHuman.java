package com.gh.pattern.factory.abstracts;
/**
* @author cbf4Life cbf4life@126.com
* I'm glad to share my knowledge with you all.
* 女性黄种人
*/
public class YellowFemaleHuman extends AbstractYellowHuman{

	@Override
	public void setSex() {
		System.out.println("该黄种人的性别为女...");
	}

}
