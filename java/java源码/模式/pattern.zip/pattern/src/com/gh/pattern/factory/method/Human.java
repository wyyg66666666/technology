package com.gh.pattern.factory.method;
/**
 * 定义一个人类的接口
 * @author Administrator
 *
 */
public interface Human {
	/**
	 * 人会笑
	 */
	public void laugh();
	/**
	 * 人会 哭
	 */
	public void cry();

}
