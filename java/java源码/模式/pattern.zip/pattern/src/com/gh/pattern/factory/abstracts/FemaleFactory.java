package com.gh.pattern.factory.abstracts;

public class FemaleFactory extends AbstractHumanFactory{

	//创建一个女性黄种人
	@Override
	public Human createYellowHuman() {
		return super.createYellowHuman(EnumHuman.YellowFemaleHuman);
	}

}
