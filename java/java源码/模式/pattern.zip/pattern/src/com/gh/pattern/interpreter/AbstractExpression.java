package com.gh.pattern.interpreter;


public interface AbstractExpression {
	//一个抽象的解释操作
	public abstract void interpret(Context context);
}
