package com.gh.pattern.factory.abstracts;

public class MaleFactory extends AbstractHumanFactory{

	//创建一个男性黄种人
	@Override
	public Human createYellowHuman() {
		return super.createYellowHuman(EnumHuman.YellowMaleHuman);
	}

}
