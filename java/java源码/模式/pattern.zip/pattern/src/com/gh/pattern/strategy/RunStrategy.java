package com.gh.pattern.strategy;

/**
 *具体策略角色， 实现接口IStrategy，采用的策略就是逃跑
 * @author Administrator
 *
 */
public class RunStrategy implements IStrategy {

	@Override
	public void operate() {
		System.out.println("快跑");
	}

}
