package com.gh.pattern.decorator;

public abstract class Decorator implements ISchoolReport {

	//首先我要知道是那个成绩单
	private ISchoolReport sr;
	
	//构造函数，传递成绩单过来
	public Decorator(ISchoolReport sr){
		this.sr = sr;
	}
	
	@Override
	public void report() {
		this.sr.report();
	}

	@Override
	public void sign(String name) {
		this.sr.sign(name);
	}

}
