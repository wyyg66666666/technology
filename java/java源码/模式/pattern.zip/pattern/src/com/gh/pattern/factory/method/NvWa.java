package com.gh.pattern.factory.method;
/**
* @author gh
* 首先定义女娲，这真是额的神呀
*/
public class NvWa {

	public static void main(String[] args) {
		
		//这次火候掌握的正好，黄色人种（不写黄人，免得引起歧义），备注：RB人不属于此列
		System.out.println("------------造出的第三批人是这样的：黄色人种-----------------");
		Human yellowHuman = new HumanFactory().createHuman(YellowPeople.class);
//		Human yellowHuman = HumanFactory.createHuman(String.class);
		if (yellowHuman!=null) {
			yellowHuman.cry();
			yellowHuman.laugh();
		}
	}

}
