package com.gh.pattern.bridge;

public class ShanZhaiCompany extends Company{

	public ShanZhaiCompany(Product product) {
		super(product);
	}

	//狂赚钱
	public void makeMoney(){
		super.makeMoney();
		System.out.println("我赚钱呀...");
	}

}
