package com.gh.pattern.facade;

public class Police {
	
	/**
	 * 警察要检查信件内容
	 * @param context
	 */
	public void checkLetter(LetterProcess letterProcess){
		System.out.println("警察要检查信件内容");
	}

}
