package com.gh.pattern.factory.method;

public abstract class AbstractHumanFactory {
	
	public abstract Human createHuman(Class<? extends Human> c);

}
