package com.gh.pattern.flyweight;

/**
 * 所有具体享元类的接口，通过这个接口，FlyWeight可以接受并作用于外部状态
 * @author Administrator
 *
 */
public interface FlyWeight {
	
	public void operation(int extrinsicstate);

}
