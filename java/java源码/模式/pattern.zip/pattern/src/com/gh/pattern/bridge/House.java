package com.gh.pattern.bridge;
/**
* @author cbf4Life cbf4life@126.com
* I'm glad to share my knowledge with you all.
* 这是我集团公司盖的房子
*/
public class House extends Product {

	@Override
	public void beProducted() {
		System.out.println("生产出的房子是这个样子的...");
	}

	@Override
	public void beSelled() {
		System.out.println("生产出的房子卖出去了...");
	}

}
