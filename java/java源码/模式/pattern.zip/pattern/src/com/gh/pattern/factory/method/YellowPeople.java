package com.gh.pattern.factory.method;

/**
 * 声明一个类继承人类接口，并且实现两个方法
 * @author Administrator
 *
 */
public class YellowPeople implements Human {

	@Override
	public void laugh() {
		System.out.println("黄种人笑");
	}

	@Override
	public void cry() {
		System.out.println("黄种人哭");
	}

}
