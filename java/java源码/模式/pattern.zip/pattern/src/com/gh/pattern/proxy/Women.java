package com.gh.pattern.proxy;

/**
 * 定义一个女性接口
 * @author Administrator
 *
 */
public interface Women {
	/**
	 * 向男的抛媚眼
	 */
	public void makeEyesToMan();

}
