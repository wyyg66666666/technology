package com.gh.pattern.command;

/**
* @author cbf4Life cbf4life@126.com
* I'm glad to share my knowledge with you all.
* 美工组的职责是设计出一套漂亮、简单、便捷的界面
*/
public class PageGroup extends Group {

	@Override
	public void find() {
		System.out.println("找到美工组...");
	}

	@Override
	public void add() {
		System.out.println("客户要求增加一个页面...");
	}

	@Override
	public void delete() {
		System.out.println("客户要求删除一个页面...");
	}

	@Override
	public void change() {
		System.out.println("客户要求修改一个页面...");
	}

	@Override
	public void plan() {
		System.out.println("客户要求页面变更计划...");
	}

}
