package com.gh.pattern.memento;
/**
 * 发起人
 * @author Administrator
 *
 */
public class Originator {
	//需要保存的属性,可能有多个
	private String state;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	/**
	 * 创建备忘录，将当前需要保存的信息导入并实例化出一个Memento对象
	 * @return
	 */
	public Memento createMemnto(){
		return new Memento(state);
	}
	
	/**
	 * 恢复备忘录
	 * @param memento
	 */
	public void setMemento(Memento memento){
		this.state = memento.getState();
	}
	
	public void show(){
		System.out.println("state="+state);
	}
}
