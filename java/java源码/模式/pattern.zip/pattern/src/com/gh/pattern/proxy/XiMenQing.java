package com.gh.pattern.proxy;

public class XiMenQing {

	public static void main(String[] args) {
		//西门庆把王婆叫出来
		WangPo wangPo = new WangPo();
		//表面上是王婆在抛媚眼，实际却是潘金莲在抛，这就是代理。
		wangPo.makeEyesToMan();

	}

}
