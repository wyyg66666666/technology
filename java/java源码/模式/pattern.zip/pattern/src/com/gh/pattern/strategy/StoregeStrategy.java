package com.gh.pattern.strategy;

/**
 * 环境角色，此类用来存放策略，并且调用策略的方法
 * @author Administrator
 *
 */
public class StoregeStrategy {
	
	private IStrategy strategy;
	
	public StoregeStrategy(IStrategy strategy){
		this.strategy = strategy;
	}
	
	/**
	 * 使用策略
	 */
	public void operate(){
		this.strategy.operate();
	}

}
