package com.gh.pattern.proxy;

/**
 * 代理必须与被代理实现同一个接口或者类，要不然就不叫代理
 * @author Administrator
 *
 */
public class WangPo implements Women {
	
	private Women women;

	/**
	 * 王婆默认代理潘金莲
	 */
	public WangPo() {
		women = new PanJinNian();
	}

	/**
	 * 王婆还可以代理其他像潘金莲这种类型的女的
	 * @param women
	 */
	public WangPo(Women women) {
		this.women = women;
	}

	/**
	 * 王婆代理女性向男人抛媚眼
	 */
	@Override
	public void makeEyesToMan() {
		women.makeEyesToMan();
	}

}
