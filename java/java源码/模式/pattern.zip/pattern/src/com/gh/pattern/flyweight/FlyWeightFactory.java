package com.gh.pattern.flyweight;

import java.util.Hashtable;

/**
 * 享元工厂，用来创建并管理FlyWeight对象。
 * @author Administrator
 *
 */
public class FlyWeightFactory {
	
	private Hashtable<String, FlyWeight> flyWeights = new Hashtable<String, FlyWeight>();

	//初始化工厂时，先生成三个实例
	public FlyWeightFactory() {
		this.flyWeights.put("X", new ConcreteFlyWeight());
		this.flyWeights.put("Y", new ConcreteFlyWeight());
		this.flyWeights.put("Z", new ConcreteFlyWeight());
	}
	
	/**
	 * 根据客户端请求，返回已生成的实例
	 * @param key
	 * @return
	 */
	public FlyWeight getFlyWeight(String key){
		return this.flyWeights.get(key);
	}

}
