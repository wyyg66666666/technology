package com.gh.pattern.decorator;
/**
* @author cbf4Life cbf4life@126.com
* I'm glad to share my knowledge with you all.
* 成绩单的接口
*/
public interface ISchoolReport {
	
	//成绩单的主要展示的就是你的成绩情况
	public void report();
	
	//成绩单要家长签字，这个是最要命的
	public void sign(String name);

}
