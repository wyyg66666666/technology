package com.gh.pattern.facade;

public class ModenPostOffice {

	private LetterProcess letterProcess = new LetterProcessImpl();
	private Police letterPolice = new Police();
	//写信，封装，投递，一体化了
	public void sendLetter(String context,String address){
		//帮你写信
		letterProcess.writeContext(context);
		//写好信封
		letterProcess.fillEnvelope(address);
		letterPolice.checkLetter(letterProcess);
		//把信放到信封中
		letterProcess.letterInotoEnvelope();
		//邮递信件
		letterProcess.sendLetter();
	}

}
