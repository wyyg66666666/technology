package com.gh.pattern.template.method;
/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * 悍马车是每个越野者的最爱，其中H2最接近军用系列
 */
public class HummerH2Model extends HummerModel{

	@Override
	public void start() {
		System.out.println("悍马H2发动...");
	}

	@Override
	public void stop() {
		System.out.println("悍马H2停车...");
	}

	@Override
	public void alarm() {
		System.out.println("悍马H2鸣笛...");
	}

	@Override
	public void engineBoom() {
		System.out.println("悍马H2引擎声音是这样在...");
	}

	/**
	 * 默认没有喇叭的
	 */
	@Override
	protected boolean isAlarm() { 
		return false;
	}

}
