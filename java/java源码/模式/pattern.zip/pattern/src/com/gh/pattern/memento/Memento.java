package com.gh.pattern.memento;
/**
 * 备忘录类
 * @author Administrator
 *
 */
public class Memento {
	
	private String state;

	//保存相关状态
	public Memento(String state) {
		this.state = state;
	}
	
	/**
	 * 获取保存的状态
	 * @return
	 */
	public String getState(){
		return this.state;
	}
}
