package com.gh.pattern.decorator;

public class Father {

	public static void main(String[] args) {
		//美化过的成绩单拿过来
		ISchoolReport sr= new SugarFouthGradeReport();
		//看成绩单
		sr.report();
		//然后老爸，一看，很开心，就签名了
		sr.sign("老三"); //我叫小三，老爸当然叫老三
		
		
		//成绩单拿过来
		ISchoolReport sr01;
		sr01 = new FourthGradeReport(); //原装的成绩单
		//加 了最高分说明的成绩单
		sr01 = new HighScoreDecorator(sr01);
		//又加了成绩排名的说明
		sr01 = new SortDecorator(sr01);
		//看成绩单
		sr01.report();
		//然后老爸，一看，很开心，就签名了
		sr01.sign("老三"); //我叫小三，老爸当然叫老三
	}

}
