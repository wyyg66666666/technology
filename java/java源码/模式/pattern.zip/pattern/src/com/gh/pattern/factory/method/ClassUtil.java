package com.gh.pattern.factory.method;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * 此类非常有用，，特别是根据接口获取所有实现类的方法
 * @author Administrator
 *
 */
public class ClassUtil {

	/**
	 * 给一个接口，返回这个接口的所有实现类
	 * @param c 可以是接口或者具体的类
	 * @return 这个接口的所有实现类，如果传进的不是接口则返回一个null
	 */
	public static List<Class> getAllClassByInterface(Class c){
		List<Class> returnClassList = new ArrayList<Class>(); //返回结果
		//如果不是一个接口，则不做处理
		if(c.isInterface()){
			String packageName = c.getPackage().getName(); //获得当前的包名
			try {
				List<Class> allClass = getClasses(packageName); //获得当前包下以及子包下的所有类
				//判断是否是同一个接口
				for(int i=0;i<allClass.size();i++){
					if(c.isAssignableFrom(allClass.get(i))){ //判断是不是一个接口
						if(!c.equals(allClass.get(i))){ //本身不加进去
							//将实现类加入到返回结果中，一个list链表
							returnClassList.add(allClass.get(i));
						} 
					}
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return returnClassList;
	}
	
	/**
	 * 从一个包中查找出所有的类，在jar包中不能查找
	 * @param packageName 包名
	 * @return 
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private static List<Class> getClasses(String packageName)
			throws ClassNotFoundException, IOException {
		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();
		String path = packageName.replace('.', '/');
		//根据包名获取其中的资源
		Enumeration<URL> resources = classLoader.getResources(path);
		//声明一个file集合，用于存放包名下的文件
		List<File> dirs = new ArrayList<File>();
		while (resources.hasMoreElements()) {
			URL resource = resources.nextElement();
			dirs.add(new File(resource.getFile()));
		}
		
		ArrayList<Class> classes = new ArrayList<Class>();
		for (File directory : dirs) {
			classes.addAll(findClasses(directory, packageName));
		}
		return classes;
	}
	
	/**
	 * 
	 * @param directory
	 * @param packageName
	 * @return
	 * @throws ClassNotFoundException
	 */
	private static List<Class> findClasses(File directory, String packageName)
			throws ClassNotFoundException {
		List<Class> classes = new ArrayList<Class>();
		//包名下的文件不存在 ，返回一个null
		if (!directory.exists()) {
			return classes;
		}
		File[] files = directory.listFiles();
		for (File file : files) {
			//如果是.表示还是文件夹，则继续迭代进去，直到找到.class文件为止
			if (file.isDirectory()) {
				assert !file.getName().contains(".");
				classes.addAll(findClasses(file, packageName + "." +
						file.getName()));
			} else if (file.getName().endsWith(".class")) {
				classes.add(Class.forName(packageName + '.' +
						file.getName().substring(0, file.getName().length() - 6)));
			}
		}
		return classes;
	}

}
