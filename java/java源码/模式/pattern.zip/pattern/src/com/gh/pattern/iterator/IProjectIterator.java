package com.gh.pattern.iterator;

import java.util.Iterator;

/**
* @author cbf4Life cbf4life@126.com
* I'm glad to share my knowledge with you all.
* 定义个Iterator接口
*/
public interface IProjectIterator extends Iterator {

}
