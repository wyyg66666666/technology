package com.gh.pattern.flyweight;

/**
 * 为内部状态增加存储空间
 * @author Administrator
 *
 */
public class ConcreteFlyWeight implements FlyWeight {

	@Override
	public void operation(int extrinsicstate) {
		System.out.println("具体FlyWeight："+extrinsicstate);
	}

}
