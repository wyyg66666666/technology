package com.gh.pattern.proxy;

public class PanJinNian implements Women {

	@Override
	public void makeEyesToMan() {
		
		System.out.println("跟西门庆抛媚眼");

	}

}
