package com.gh.pattern.memento;

public class Client {

	public static void main(String[] args) {
		//Originator初始状态为on
		Originator o = new Originator();
		o.setState("On");
		o.show();
		
		//保存初始状态
		Caretaker c = new Caretaker();
		c.setMemento(o.createMemnto());
		
		//重新设置Originator状态
		o.setState("Off");
		o.show();
		
		//恢复到初始状态
		o.setMemento(c.getMemento());
		o.show();
	}

}
