package com.gh.pattern.strategy;

/**
 * 抽象策略角色，定义了策略接口，实现该接口的类将是采用具体的策略
 * @author Administrator
 *
 */
public interface IStrategy {

	public void operate();
	
}
